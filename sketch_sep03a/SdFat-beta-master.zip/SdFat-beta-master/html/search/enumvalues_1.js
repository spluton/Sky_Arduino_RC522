var searchData=
[
  ['cur',['cur',['../classios__base.html#ab01103ba35f6ba93a704b3ec0c86191ea53910041525b9e2f33bfc3bb4482134c',1,'ios_base']]]
];
