//-----------------------------------------------------------------------------
// This code is licensed to you under the terms of the GNU GPL, version 2 or,
// at your option, any later version. See the LICENSE.txt file for the text of
// the license.
//-----------------------------------------------------------------------------
// CRC64 ECMA
//-----------------------------------------------------------------------------
#include <stdint.h>
#include <stdlib.h>
#ifndef __PRECALC_H
#define __PRECALC_H
void *GetOne(char * uid,char sector, uint8_t *Key );

//void crc64 (const uint8_t *data, const size_t len, uint64_t *crc) ;

#endif
